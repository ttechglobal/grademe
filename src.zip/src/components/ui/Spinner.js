import { cn } from '@/lib/utils'

export default function Spinner({ className }) {
  return (
    <svg
      className={cn('animate-spin h-5 w-5 text-brand-500', className)}
      fill="none"
      viewBox="0 0 24 24"
    >
      <circle
        className="opacity-25"
        cx="12" cy="12" r="10"
        stroke="currentColor"
        strokeWidth="4"
      />
      <path
        className="opacity-75"
        fill="currentColor"
        d="M4 12a8 8 0 018-8v8z"
      />
    </svg>
  )
}